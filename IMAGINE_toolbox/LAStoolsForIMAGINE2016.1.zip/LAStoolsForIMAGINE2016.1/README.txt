Installation instructions can be found in the file "Install LAStoolsForIMAGINE.pdf" located in the Docs folder of this installation.
