Prototype for beta testing of LAStools in ERDAS IMAGINE 2014

(1) Modify the entries of the "InstallLAStoolsForIMAGINE.bat"
    file listed below to match your local settings:

SET IMAGINE_PATH=C:\Program Files\Intergraph\ERDAS IMAGINE 2014
SET IMAGINE_PLUGINS_BASE_PATH=C:\Program Files (x86)\Common Files\Intergraph

(2) Exit ERDAS IMAGINE 2014.

(3) Run "InstallLAStoolsForIMAGINE.bat" as administrator.

(4) Start ERDAS IMAGINE 2014.

(5) Go to File->Preferences->Other->LAStools and set the LAStools
    Installation Path to where you have your LAStools distribution.

(6) Switch to the LAStools tab and start using LAStools both here
    and in the Spatial Modeller.
     