The LAStools LiDAR toolbox for ERDAS IMAGINE 2015

Installation instructions can be found in the file
called LAStools_for_IMAGINE_Installation_Guide.pdf
located in the docs folder of this distribution.
